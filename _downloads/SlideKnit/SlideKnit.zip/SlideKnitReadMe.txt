###

SlideKnit

Version : 2008.09.25
Created for Slide Ltd (http://slidelondon.com) in Sept 2008 by Robin Deitch (contact@slidelondon.com)

###

About :

This tool can help you lay things out on the surface of complex objects which have been UV-mapped. For
example, you could craft an intricately-detailed knit-pattern mesh in a flat plane, then wrap this
around a sweater mesh.

To use, first select a single source object, which has been properly UV mapped. In the tool, pick a
mapping channel and a scale for the flattened mesh - then hit the "Unwrap selected" button. It will
create a new mesh named [source name]_skFlat_channel[channel], based on the UVs of the base object and
arbitrarily scaled from the [0..1] UV space. This will have a morph modifier in the stack which will
transform the verts from UV to world positions. You should be able to slide channel 1 up to 100 and
see the flat mesh move into place on top of the source mesh.

You can now lay some other objects on top of the flattened mesh and skin wrap these to it. When you
morph the flat mesh and your bits and pieces will morph with it!


Installation :

1. With 3dsmax closed, place the .mcr file in [3dsmaxroot]/ui/macroscripts/
2. Open 3dsmax
3. Go to Customize->Customize User Interface...->Toolbars, and set Category to 'Slide Tools'
4. Drag SlideKnit to a comfy spot on a toolbar
5. Close the Customize User Interface dialog box
6. Click on the new button to open the tool

###